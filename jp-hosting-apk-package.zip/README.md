# JP Hosting APK Package

## 🚀 Build APK Online

### Option 1: PhoneGap Build (Recommended)
1. Create account at https://build.phonegap.com
2. Upload this folder as ZIP
3. Build APK online
4. Download your APK

### Option 2: Capacitor Cloud Build
1. Go to https://capacitorjs.com/
2. Use online build service
3. Upload this package
4. Get APK download link

### Option 3: Local Build (if you have Android Studio)
1. Install Capacitor CLI: `npm install -g @capacitor/cli`
2. Run: `npx cap add android`
3. Run: `npx cap sync android`
4. Open in Android Studio: `npx cap open android`
5. Build APK

## 📱 Features in Your APK:
- 🎮 Advanced Server Control Panel (Darco-style)
- 🌐 Custom Domain Management (free .hosting.jp + paid domains)
- 💰 UPI Payment Integration (jaydendpenha@fam)
- 📊 Real-time Server Monitoring
- 📁 File Manager with Editor
- 🔐 Persistent Authentication
- 🎨 Beautiful Modern UI

## 💳 Payment Info:
All transactions go to UPI ID: **jaydendpenha@fam**

## 🆓 Free Plan:
Get your first server free for 7 days + free .hosting.jp domain!
